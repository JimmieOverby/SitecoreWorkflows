This package installs a mail workflow action. 
Due to the fact that the actual workflows can be 
different in each installation, the action node is 
installed to the root of workflows. You should move 
it under the command you prefer.